 <?php
 $message=" <!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'><html xmlns='http://www.w3.org/1999/xhtml'><head>
    <html lang='en'>
	<head>
	<title></title>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link href='https://fonts.googleapis.com/icon?family=Material+Icons' rel='stylesheet'>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.0/css/materialize.min.css'>
  <script src='https://code.jquery.com/jquery-2.1.4.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.0/js/materialize.min.js'></script>
  </head>
  <body>
   <header class='header blue darken-4 z-depth-1' style='text-align:center;padding-top:0.3em;padding-bottom:0.02em' align='middle'>
      <h4 class='header light white-text'>GraVITas'15 - User Authentication</h4> </header>
       Dear Participant, <br><br/>
      Greetings!! <br/><br/>
	 Please follow the link to activate account :<a href='localhost/gravitas-15/externals/password_reset.php?p=$ResultStr&e=$email&r=$regno'>Link</a> 
	 <br><br/>
   Regards,<br><br/>
   Team Gravitas'15,<br>
   VIT University,<br>
   Vellore.<br/><br/>

   For Technical Assistance: <br/>
   Ph: +91 9092658797<br/>
   Email: shambhavi110@gmail.com<br/>


	</body>
</html>";
?>
	
