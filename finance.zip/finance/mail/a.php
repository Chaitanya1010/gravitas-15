<?php
require("class.phpmailer.php");
$mail = new PHPMailer();
?>